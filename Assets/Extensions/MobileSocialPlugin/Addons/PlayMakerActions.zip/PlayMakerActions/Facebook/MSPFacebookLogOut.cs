using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin")]
	public class MSPFacebookLogOut : FsmStateAction {

		public override void OnEnter() {
			SPFacebook.instance.Logout();
			Finish();

		}

	}
}


