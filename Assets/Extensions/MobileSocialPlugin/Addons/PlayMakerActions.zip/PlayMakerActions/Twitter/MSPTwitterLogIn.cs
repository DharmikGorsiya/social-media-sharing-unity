using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin")]
	public class MSPTwitterLogIn : FsmStateAction {

		private static string TWITTER_CONSUMER_KEY = "TWITTER_CONSUMER_KEY";
		private static string TWITTER_CONSUMER_SECRET = "TWITTER_CONSUMER_SECRET";


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			if(SPTwitter.twitter.IsAuthed) {
				OnSuccses();
				return;
			}

			SPTwitter.twitter.Init(TWITTER_CONSUMER_KEY, TWITTER_CONSUMER_SECRET);

			SPTwitter.twitter.addEventListener(TwitterEvents.AUTHENTICATION_SUCCEEDED,  OnSuccses);
			SPTwitter.twitter.addEventListener(TwitterEvents.AUTHENTICATION_FAILED,  	OnFail);


			SPTwitter.twitter.AuthificateUser();


		}

		private void RemoveListners() {
			SPTwitter.twitter.removeEventListener(TwitterEvents.AUTHENTICATION_SUCCEEDED,  OnSuccses);
			SPTwitter.twitter.removeEventListener(TwitterEvents.AUTHENTICATION_FAILED,  	OnFail);
		}

		private void OnFail() {
			Fsm.Event(failEvent);
			RemoveListners();
			Finish();
		}
		
		private void OnSuccses() {

			if(!SPTwitter.twitter.IsAuthed) {
				OnFail();
				return;
			}

			Fsm.Event(successEvent);
			RemoveListners();
			Finish();
		}

	}
}


