using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin")]
	public class MSPTwitterPost : FsmStateAction {

		public string message;


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}


			SPTwitter.twitter.addEventListener(TwitterEvents.POST_SUCCEEDED,  OnPostSuccses);
			SPTwitter.twitter.addEventListener(TwitterEvents.POST_FAILED,  	  OnPostFailed);


			SPTwitter.Post(message);

		}

		private void RemoveListners() {
			SPTwitter.twitter.removeEventListener(TwitterEvents.POST_SUCCEEDED,  OnPostSuccses);
			SPTwitter.twitter.removeEventListener(TwitterEvents.POST_FAILED,  	  OnPostFailed);
		}

		private void OnPostFailed() {
			Fsm.Event(failEvent);
			RemoveListners();
			Finish();
		}
		
		private void OnPostSuccses() {
			Fsm.Event(successEvent);
			RemoveListners();
			Finish();
		}

	}
}


