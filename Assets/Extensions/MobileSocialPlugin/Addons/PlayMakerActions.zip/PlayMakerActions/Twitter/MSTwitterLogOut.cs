using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin")]
	public class MSTwitterLogOut : FsmStateAction {

		public override void OnEnter() {
			SPTwitter.twitter.LogOut();
			Finish();

		}

	}
}


